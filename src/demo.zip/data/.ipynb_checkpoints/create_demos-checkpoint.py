import numpy as np
import pandas as pd

# load test data
test_df = pd.read_csv("test.csv", index_col=0)
# select 10 random recipes to use as demo
demo_recipes = np.random.choice(len(test_df), size=10)
# save dataframe of just these demo recipes
demo_df = test_df.iloc[demo_recipes]
demo_df.to_csv("data/test.csv")